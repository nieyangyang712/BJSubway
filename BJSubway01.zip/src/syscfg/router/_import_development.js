// module.exports = file => require('@/src/syscfg/' + file + '.vue')
module.exports = file => require('../' + file + '.vue')
