<template>
  <footer class="app-footer">
    &copy; 2020 
    <span class="float-right">Powered by <a href="https://blog.csdn.net/qq_41646249">nyy</a></span>
  </footer>
</template>
<script>
export default {
  name: 'footer'
}
</script>
